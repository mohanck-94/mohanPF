export interface PipelineStage {
  id: string;
  label: string;
  detail: string;
  items: string[];
}

export interface Project {
  id: "supply-chain" | "price-promo";
  number: string;
  title: string;
  domain: string;
  summary: string;
  challenge: string;
  contributions: string[];
  stack: string[];
  stages: PipelineStage[];
}

export const projects: Project[] = [
  {
    id: "supply-chain",
    number: "01",
    title: "Consumer Electronics Supply Chain",
    domain: "Supply chain · Consumer electronics",
    summary:
      "End-to-end data platform connecting orders, supplier shipments and warehouse inventory into one view of product flow from factory to store.",
    challenge:
      "Order, shipment and inventory data lived in separate systems with different product codes and refresh cycles, so planners could not see stock positions and inbound supply in one place.",
    contributions: [
      "Designed ingestion pipelines for ERP orders, supplier shipment feeds and warehouse inventory snapshots",
      "Built a layered lakehouse (raw → cleansed → curated) with a conformed product and location master",
      "Modelled inventory position, in-transit stock and supplier lead-time tables for planning",
      "Added data-quality checks and pipeline monitoring for late or incomplete supplier files",
      "Published curated datasets for planning dashboards and replenishment reporting",
    ],
    stack: ["Azure Data Factory", "Databricks", "PySpark", "Delta Lake", "SQL", "Power BI"],
    stages: [
      {
        id: "sources",
        label: "Sources",
        detail: "Operational systems feeding the platform.",
        items: ["ERP sales & purchase orders", "Supplier shipment notices", "Warehouse inventory snapshots", "Product & location masters"],
      },
      {
        id: "ingest",
        label: "Ingest",
        detail: "Scheduled and incremental loads into the raw zone.",
        items: ["Parameterised copy pipelines", "Incremental loads by watermark", "File arrival checks for supplier feeds"],
      },
      {
        id: "lakehouse",
        label: "Lakehouse",
        detail: "Layered storage from raw to curated.",
        items: ["Raw: data as received", "Cleansed: typed, de-duplicated, code-mapped", "Curated: conformed product / location dimensions"],
      },
      {
        id: "model",
        label: "Model",
        detail: "Analytical tables used by planners.",
        items: ["Inventory position by SKU × location", "In-transit and inbound supply", "Supplier lead-time history"],
      },
      {
        id: "serve",
        label: "Serve",
        detail: "Where the data is consumed.",
        items: ["Supply planning dashboards", "Replenishment reports", "Data-quality monitoring"],
      },
    ],
  },
  {
    id: "price-promo",
    number: "02",
    title: "Retail Stores' Price & Promo Adviser",
    domain: "Retail · Pricing & promotions",
    summary:
      "Data foundation for an adviser that helps retail teams review prices and plan promotions using historical sales, price and promotion data.",
    challenge:
      "Store sales, price lists and promotion calendars were recorded at different grains, making it hard to compare how products sold at regular price versus on promotion.",
    contributions: [
      "Ingested store-level POS transactions, price lists and the promotion calendar",
      "Aligned sales, price and promo data to a common product × store × week grain",
      "Built feature tables for regular-price and promoted-period sales history",
      "Delivered curated outputs consumed by the adviser's recommendation logic",
      "Automated refreshes with validation of price and promo reference data",
    ],
    stack: ["Azure Data Factory", "Databricks", "PySpark", "Delta Lake", "SQL", "Power BI"],
    stages: [
      {
        id: "sources",
        label: "Sources",
        detail: "Retail data feeding the adviser.",
        items: ["Store POS transactions", "Price lists & price changes", "Promotion calendar & mechanics", "Product hierarchy & store master"],
      },
      {
        id: "ingest",
        label: "Ingest",
        detail: "Daily loads of transactions and reference data.",
        items: ["Daily POS extracts", "Price & promo reference loads", "Schema and completeness validation"],
      },
      {
        id: "harmonise",
        label: "Harmonise",
        detail: "One consistent grain across all inputs.",
        items: ["Product × store × week aggregation", "Promo flags joined to sales periods", "Effective-dated price history"],
      },
      {
        id: "features",
        label: "Features",
        detail: "Inputs prepared for the adviser.",
        items: ["Regular vs promoted sales history", "Price-change history per product", "Promotion attributes by period"],
      },
      {
        id: "advise",
        label: "Advise",
        detail: "Outputs used by retail teams.",
        items: ["Price & promo recommendation tables", "Category review reports", "Refresh and data-quality logs"],
      },
    ],
  },
];
