import { useId, useState } from "react";
import { ArrowRight, ArrowDown, CheckCircle2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { projects, type Project } from "@/data/projects";

/* ---------- Tile illustrations (inline SVG, theme-aware) ---------- */

function SupplyChainArt({ titleId, descId }: { titleId: string; descId: string }) {
  return (
    <svg viewBox="0 0 400 200" role="img" aria-labelledby={`${titleId} ${descId}`} className="h-full w-full">
      <title id={titleId}>Supply chain flow</title>
      <desc id={descId}>Factory ships to a distribution centre, which supplies retail stores; data flows back to a central platform.</desc>
      <defs>
        <pattern id="sc-grid" width="20" height="20" patternUnits="userSpaceOnUse">
          <path d="M20 0H0V20" fill="none" className="stroke-border" strokeWidth="1" />
        </pattern>
      </defs>
      <rect width="400" height="200" fill="url(#sc-grid)" />
      {/* routes */}
      <path d="M78 130 C 130 130, 140 100, 190 100" fill="none" className="stroke-primary" strokeWidth="3" strokeDasharray="7 6" />
      <path d="M232 100 C 280 100, 290 60, 330 60" fill="none" className="stroke-primary" strokeWidth="3" strokeDasharray="7 6" />
      <path d="M232 100 C 280 100, 290 145, 330 145" fill="none" className="stroke-primary" strokeWidth="3" strokeDasharray="7 6" />
      {/* factory */}
      <g className="fill-card stroke-foreground" strokeWidth="2">
        <path d="M30 150 V110 L48 120 V110 L66 120 V96 H78 V150 Z" />
      </g>
      <rect x="40" y="134" width="8" height="10" className="fill-primary" />
      <rect x="56" y="134" width="8" height="10" className="fill-primary" />
      {/* distribution centre */}
      <g className="fill-card stroke-foreground" strokeWidth="2">
        <path d="M188 120 V88 L211 74 L234 88 V120 Z" />
      </g>
      <rect x="200" y="100" width="22" height="20" className="fill-muted stroke-foreground" strokeWidth="1.5" />
      <line x1="200" y1="107" x2="222" y2="107" className="stroke-foreground" strokeWidth="1" />
      <line x1="200" y1="114" x2="222" y2="114" className="stroke-foreground" strokeWidth="1" />
      {/* stores */}
      {[{ y: 40 }, { y: 125 }].map(({ y }) => (
        <g key={y}>
          <rect x="332" y={y} width="44" height="36" rx="3" className="fill-card stroke-foreground" strokeWidth="2" />
          <rect x="332" y={y} width="44" height="9" rx="2" className="fill-primary" />
          <rect x="344" y={y + 18} width="20" height="18" className="fill-muted stroke-foreground" strokeWidth="1.5" />
        </g>
      ))}
      {/* parcels */}
      {[{ x: 120, y: 118 }, { x: 272, y: 72 }, { x: 274, y: 120 }].map(({ x, y }) => (
        <g key={`${x}-${y}`}>
          <rect x={x} y={y} width="16" height="13" rx="2" className="fill-card stroke-foreground" strokeWidth="1.5" />
          <line x1={x + 8} y1={y} x2={x + 8} y2={y + 13} className="stroke-foreground" strokeWidth="1" />
        </g>
      ))}
      {/* data platform */}
      <g>
        <ellipse cx="211" cy="30" rx="26" ry="7" className="fill-primary" />
        <path d="M185 30 V46 A26 7 0 0 0 237 46 V30" className="fill-primary" />
        <ellipse cx="211" cy="30" rx="26" ry="7" className="fill-none stroke-primary-foreground" strokeWidth="1" />
      </g>
      <path d="M211 72 V56" className="stroke-foreground" strokeWidth="1.5" strokeDasharray="3 3" />
      <path d="M54 94 C 60 50, 150 34, 182 36" fill="none" className="stroke-foreground" strokeWidth="1.5" strokeDasharray="3 3" />
      <path d="M352 38 C 340 20, 270 28, 240 34" fill="none" className="stroke-foreground" strokeWidth="1.5" strokeDasharray="3 3" />
    </svg>
  );
}

function PricePromoArt({ titleId, descId }: { titleId: string; descId: string }) {
  const products = [
    { x: 40, h: 46, price: "₹499", promo: false },
    { x: 110, h: 60, price: "₹1,299", promo: true },
    { x: 180, h: 38, price: "₹249", promo: false },
  ];
  const bars = [30, 34, 31, 58, 62, 36, 33, 35];
  return (
    <svg viewBox="0 0 400 200" role="img" aria-labelledby={`${titleId} ${descId}`} className="h-full w-full">
      <title id={titleId}>Store shelf with price and promotion tags</title>
      <desc id={descId}>Products on a shelf carry price tags, one marked with a promotion; beside it, weekly sales bars rise during a promoted period.</desc>
      <defs>
        <pattern id="pp-grid" width="20" height="20" patternUnits="userSpaceOnUse">
          <path d="M20 0H0V20" fill="none" className="stroke-border" strokeWidth="1" />
        </pattern>
      </defs>
      <rect width="400" height="200" fill="url(#pp-grid)" />
      {/* shelf */}
      <rect x="24" y="150" width="216" height="8" rx="2" className="fill-foreground" />
      {products.map((p) => (
        <g key={p.x}>
          <rect x={p.x} y={150 - p.h} width="44" height={p.h} rx="4" className="fill-card stroke-foreground" strokeWidth="2" />
          <rect x={p.x + 8} y={150 - p.h + 10} width="28" height="6" rx="2" className="fill-muted" />
          {/* tag */}
          <g>
            <rect x={p.x - 2} y="162" width="48" height="20" rx="3" className={p.promo ? "fill-primary" : "fill-card stroke-foreground"} strokeWidth="1.5" />
            <text x={p.x + 22} y="176" textAnchor="middle" fontSize="11" fontWeight="600" className={p.promo ? "fill-primary-foreground" : "fill-foreground"}>
              {p.price}
            </text>
          </g>
        </g>
      ))}
      {/* promo burst */}
      <g transform="translate(150 70)">
        <circle r="18" className="fill-primary" />
        <text y="4" textAnchor="middle" fontSize="11" fontWeight="700" className="fill-primary-foreground">%</text>
      </g>
      {/* weekly sales bars */}
      <line x1="270" y1="158" x2="384" y2="158" className="stroke-foreground" strokeWidth="1.5" />
      <rect x="306" y="40" width="30" height="118" className="fill-muted" />
      {bars.map((b, i) => (
        <rect key={i} x={272 + i * 14} y={158 - b * 1.6} width="9" height={b * 1.6} rx="1.5" className={i === 3 || i === 4 ? "fill-primary" : "fill-foreground/40"} />
      ))}
      <text x="321" y="34" textAnchor="middle" fontSize="10" className="fill-foreground">promo weeks</text>
    </svg>
  );
}

function ProjectArt({ id }: { id: Project["id"] }) {
  const t = useId();
  const d = useId();
  return id === "supply-chain" ? <SupplyChainArt titleId={t} descId={d} /> : <PricePromoArt titleId={t} descId={d} />;
}

/* ---------- Pipeline explorer inside the glimpse ---------- */

function PipelineExplorer({ project }: { project: Project }) {
  const [active, setActive] = useState(project.stages[0].id);
  const stage = project.stages.find((s) => s.id === active) ?? project.stages[0];
  const panelId = useId();
  return (
    <section aria-labelledby={`${panelId}-h`} className="min-w-0 space-y-3">
      <h3 id={`${panelId}-h`} className="text-sm font-semibold">Data pipeline</h3>
      <ol className="grid grid-cols-1 gap-2 md:grid-cols-5 md:gap-6">
        {project.stages.map((s, i) => {
          const selected = s.id === active;
          return (
            <li key={s.id} className="relative min-w-0">
              <button
                type="button"
                onClick={() => setActive(s.id)}
                aria-pressed={selected}
                aria-controls={panelId}
                className={
                  "flex h-full w-full min-w-0 items-center justify-center gap-1.5 rounded-md border px-3 py-2.5 text-center text-sm font-medium leading-snug break-words whitespace-normal transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring " +
                  (selected
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-card text-foreground hover:bg-muted")
                }
              >
                <span className="tabular-nums opacity-80">{i + 1}.</span>
                <span>{s.label}</span>
              </button>
              {i < project.stages.length - 1 && (
                <>
                  <ArrowRight
                    className="pointer-events-none absolute top-1/2 -right-5 hidden size-4 -translate-y-1/2 text-muted-foreground md:block"
                    aria-hidden="true"
                  />
                  <ArrowDown className="mx-auto mt-1 size-4 text-muted-foreground md:hidden" aria-hidden="true" />
                </>
              )}
            </li>
          );
        })}
      </ol>
      <div id={panelId} aria-live="polite" className="rounded-lg border border-border bg-muted/40 p-4 sm:p-5">
        <p className="text-sm font-semibold">{stage.label}</p>
        <p className="mt-0.5 text-sm text-foreground/80">{stage.detail}</p>
        <ul className="mt-3 grid gap-x-6 gap-y-2 sm:grid-cols-2">
          {stage.items.map((it) => (
            <li key={it} className="flex min-w-0 items-start gap-2 text-sm leading-relaxed">
              <span className="mt-2 size-1.5 shrink-0 rounded-full bg-primary" aria-hidden="true" />
              <span className="min-w-0 break-words">{it}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function ProjectGlimpse({ project, onClose }: { project: Project | null; onClose: () => void }) {
  return (
    <Dialog open={project !== null} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[92dvh] w-[calc(100%-2rem)] gap-6 overflow-y-auto p-6 sm:max-w-[min(72rem,calc(100%-3rem))] sm:p-8 [&>*]:min-w-0">
        {project && (
          <>
            <DialogHeader className="pr-10 text-left">
              <p className="text-xs font-medium uppercase tracking-wider text-foreground/70">
                Project {project.number} · {project.domain}
              </p>
              <DialogTitle className="text-2xl leading-tight tracking-tight sm:text-3xl">{project.title}</DialogTitle>
              <DialogDescription className="max-w-3xl text-base text-foreground/80">{project.summary}</DialogDescription>
            </DialogHeader>

            <div className="grid min-w-0 gap-8 lg:grid-cols-[minmax(0,5fr)_minmax(0,6fr)]">
              <div className="flex min-w-0 flex-col gap-6">
                <figure className="m-0 aspect-[2/1] w-full overflow-hidden rounded-lg border border-border bg-card">
                  <ProjectArt id={project.id} />
                </figure>
                <section aria-labelledby={`${project.id}-challenge`}>
                  <h3 id={`${project.id}-challenge`} className="text-sm font-semibold">The challenge</h3>
                  <p className="mt-1.5 text-sm leading-relaxed">{project.challenge}</p>
                </section>
              </div>

              <div className="flex min-w-0 flex-col gap-6">
                <section aria-labelledby={`${project.id}-work`}>
                  <h3 id={`${project.id}-work`} className="text-sm font-semibold">What I built</h3>
                  <ul className="mt-2 space-y-2.5">
                    {project.contributions.map((c) => (
                      <li key={c} className="flex min-w-0 items-start gap-2.5 text-sm leading-relaxed">
                        <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
                        <span className="min-w-0">{c}</span>
                      </li>
                    ))}
                  </ul>
                </section>

                <section aria-labelledby={`${project.id}-stack`}>
                  <h3 id={`${project.id}-stack`} className="text-sm font-semibold">Tech stack</h3>
                  <ul className="mt-2 flex flex-wrap gap-1.5">
                    {project.stack.map((s) => (
                      <li key={s}>
                        <Badge variant="secondary" className="font-mono text-xs">{s}</Badge>
                      </li>
                    ))}
                  </ul>
                </section>
              </div>
            </div>

            <div className="border-t border-border pt-6">
              <PipelineExplorer project={project} />
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

/* ---------- Page ---------- */

export function HomePage() {
  const [openId, setOpenId] = useState<Project["id"] | null>(null);
  const openProject = projects.find((p) => p.id === openId) ?? null;
  const allSkills = Array.from(new Set(projects.flatMap((p) => p.stack)));

  return (
    <div className="mx-auto w-full max-w-6xl px-6 pb-16 pt-10">
      <section aria-labelledby="intro" className="grid gap-6 border-b border-border pb-10 md:grid-cols-[1fr_auto] md:items-end">
        <div>
          <p className="text-sm font-medium text-foreground/70">Portfolio</p>
          <h1 id="intro" className="mt-1 text-4xl font-semibold tracking-tight sm:text-5xl">Mohan C K</h1>
          <p className="mt-2 text-xl text-foreground/80">Data Engineer</p>
        </div>
        <ul aria-label="Core skills" className="flex max-w-md flex-wrap gap-1.5 md:justify-end">
          {allSkills.map((s) => (
            <li key={s}>
              <Badge variant="outline" className="font-mono text-xs">{s}</Badge>
            </li>
          ))}
        </ul>
      </section>

      <section id="projects" tabIndex={-1} aria-labelledby="projects-h" className="pt-10 outline-none">
        <div className="mb-5 flex items-baseline justify-between">
          <h2 id="projects-h" className="text-2xl font-semibold tracking-tight">Projects</h2>
          <span className="text-sm text-foreground/70">{projects.length} projects</span>
        </div>

        <ul className="grid gap-6 md:grid-cols-2">
          {projects.map((p) => (
            <li key={p.id}>
              <button
                type="button"
                onClick={() => setOpenId(p.id)}
                aria-haspopup="dialog"
                aria-expanded={openId === p.id}
                className="group flex h-full w-full flex-col overflow-hidden rounded-xl border border-border bg-card text-left shadow-sm transition-all hover:-translate-y-0.5 hover:border-primary hover:shadow-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
              >
                <figure className="m-0 aspect-[2/1] w-full border-b border-border bg-background">
                  <ProjectArt id={p.id} />
                </figure>
                <div className="flex flex-1 flex-col gap-2 p-5">
                  <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-foreground/70">
                    <span className="tabular-nums">{p.number}</span>
                    <span aria-hidden="true">·</span>
                    <span>{p.domain}</span>
                  </div>
                  <h3 className="text-xl font-semibold tracking-tight">{p.title}</h3>
                  <p className="text-sm leading-relaxed text-foreground/80">{p.summary}</p>
                  <span className="mt-auto inline-flex items-center gap-1.5 pt-3 text-sm font-medium text-primary">
                    View project
                    <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
                  </span>
                </div>
              </button>
            </li>
          ))}
        </ul>
      </section>

      <ProjectGlimpse project={openProject} onClose={() => setOpenId(null)} />
    </div>
  );
}
